const el = id => document.getElementById(id);
el('go').addEventListener('click', async () => {
  const a = el('a').value;
  const b = el('b').value;
  const op = el('op').value;
  const resEl = el('result');
  resEl.textContent = 'Calculating...';
  try {
    // perform calculation locally (no backend required)
    const x = Number(a);
    const y = Number(b);
    if (Number.isNaN(x) || Number.isNaN(y)) throw new Error('Invalid numbers');
    let result;
    switch (op) {
      case '+': result = x + y; break;
      case '-': result = x - y; break;
      case '*': result = x * y; break;
      case '/':
        if (y === 0) throw new Error('Division by zero');
        result = x / y; break;
      default: throw new Error('Unknown operation');
    }
    resEl.textContent = 'Result: ' + result;
  } catch (err) {
    resEl.textContent = 'Error: ' + err.message;
  }
});
